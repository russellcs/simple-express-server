function welcome(content) {
  return `<div>Some HTML ${content}</div>`;
}

module.exports = welcome;
